# E5 Results Summary — Calib-BERT v2

Source SHA-256: `2f11edbeeb39b42b9f9fb2f2c5f50f03a52afb7658026f335f7a1da4092a96d1`
Official test cases per condition: 715

## Primary AURC
- M0 Vanilla: AURC=0.085326; full-coverage risk=0.186014; full-coverage stress recall=0.861789
- M0 + Temperature Scaling: AURC=0.085326; full-coverage risk=0.186014; full-coverage stress recall=0.861789
- M1 LS 0.10: AURC=0.117791; full-coverage risk=0.202797; full-coverage stress recall=0.840108

## Temperature-scaling rank invariance
- Same confidence ranking: True
- Same predicted labels: True
- Maximum risk-curve difference: 0.0
- AURC difference: 0.0

## Interpretation guardrails
- Lower AURC indicates lower average selective risk over the full coverage range.
- Fixed-coverage comparisons assess confidence ranking more fairly than equal probability thresholds.
- Equal probability thresholds can imply very different coverage after calibration.
- Formal cluster-aware uncertainty and multiplicity-controlled inference are deferred to E7.