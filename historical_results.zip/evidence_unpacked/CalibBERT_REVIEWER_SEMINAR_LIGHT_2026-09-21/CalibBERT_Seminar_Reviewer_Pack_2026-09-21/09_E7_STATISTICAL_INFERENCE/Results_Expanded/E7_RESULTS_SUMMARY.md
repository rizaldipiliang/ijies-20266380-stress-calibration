# E7 Cluster-Aware Statistical Inference Summary

- Official-test rows: 715
- Unique post_id clusters: 586
- Cluster bootstrap replicates: 10000
- Cluster sign-flip draws: 10000

## Family A — cross-backbone proper scores
- BERT | TS_minus_Vanilla | brier: Δ=-0.015892, 95% CI [-0.021523, -0.010354], Holm p=0.00119988, lower proper loss under intervention.
- BERT | TS_minus_Vanilla | nll: Δ=-0.130243, 95% CI [-0.174037, -0.089888], Holm p=0.00119988, lower proper loss under intervention.
- BERT | LS_minus_Vanilla | brier: Δ=-0.010841, 95% CI [-0.018011, -0.003797], Holm p=0.00519948, lower proper loss under intervention.
- BERT | LS_minus_Vanilla | nll: Δ=-0.112292, 95% CI [-0.158040, -0.068074], Holm p=0.00119988, lower proper loss under intervention.
- RoBERTa | TS_minus_Vanilla | brier: Δ=-0.016988, 95% CI [-0.022981, -0.011198], Holm p=0.00119988, lower proper loss under intervention.
- RoBERTa | TS_minus_Vanilla | nll: Δ=-0.112850, 95% CI [-0.154181, -0.072436], Holm p=0.00119988, lower proper loss under intervention.
- RoBERTa | LS_minus_Vanilla | brier: Δ=-0.017192, 95% CI [-0.025168, -0.009468], Holm p=0.00119988, lower proper loss under intervention.
- RoBERTa | LS_minus_Vanilla | nll: Δ=-0.109688, 95% CI [-0.153655, -0.067249], Holm p=0.00119988, lower proper loss under intervention.
- DeBERTa | TS_minus_Vanilla | brier: Δ=-0.013940, 95% CI [-0.019534, -0.008512], Holm p=0.00119988, lower proper loss under intervention.
- DeBERTa | TS_minus_Vanilla | nll: Δ=-0.134180, 95% CI [-0.180350, -0.089837], Holm p=0.00119988, lower proper loss under intervention.
- DeBERTa | LS_minus_Vanilla | brier: Δ=-0.010725, 95% CI [-0.017878, -0.003987], Holm p=0.00519948, lower proper loss under intervention.
- DeBERTa | LS_minus_Vanilla | nll: Δ=-0.125088, 95% CI [-0.174032, -0.077721], Holm p=0.00119988, lower proper loss under intervention.

## Family B — domain shift / OOD proper scores
- Vanilla_OOD_minus_Vanilla_ID | brier: Δ=0.005138, 95% CI [-0.003221, 0.013391], Holm p=0.941906, higher proper loss under OOD.
- Vanilla_OOD_minus_Vanilla_ID | nll: Δ=-0.006284, 95% CI [-0.037511, 0.025781], Holm p=1, lower proper loss under OOD.
- Vanilla+TS_OOD_minus_Vanilla+TS_ID | brier: Δ=0.006340, 95% CI [0.000317, 0.012205], Holm p=0.208179, higher proper loss under OOD.
- Vanilla+TS_OOD_minus_Vanilla+TS_ID | nll: Δ=0.014795, 95% CI [-0.000285, 0.029967], Holm p=0.280472, higher proper loss under OOD.
- LS0.10_OOD_minus_LS0.10_ID | brier: Δ=0.002394, 95% CI [-0.004434, 0.009425], Holm p=1, higher proper loss under OOD.
- LS0.10_OOD_minus_LS0.10_ID | nll: Δ=0.000589, 95% CI [-0.017053, 0.018751], Holm p=1, higher proper loss under OOD.
- TS_minus_Vanilla_OOD | brier: Δ=-0.014690, 95% CI [-0.020083, -0.009516], Holm p=0.0009999, lower proper loss under intervention.
- TS_minus_Vanilla_OOD | nll: Δ=-0.109164, 95% CI [-0.150957, -0.071188], Holm p=0.0009999, lower proper loss under intervention.
- LS_minus_Vanilla_OOD | brier: Δ=-0.013585, 95% CI [-0.020351, -0.006852], Holm p=0.00139986, lower proper loss under intervention.
- LS_minus_Vanilla_OOD | nll: Δ=-0.105418, 95% CI [-0.147378, -0.065076], Holm p=0.0009999, lower proper loss under intervention.

## Scope limitation
- Confidence intervals and p-values quantify clustered test-sample uncertainty conditional on the frozen fitted models.
- They do not quantify retraining-seed / optimization uncertainty.
- E6 fine-grained topic identities remain diagnostic because topic resolution was seed-sensitive; no individual topic hotspot is promoted by post-hoc p-values.